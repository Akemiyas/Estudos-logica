#include <stdio.h>

int main(){
 int codigo, quantidade;
 double valor;
 scanf("%d", &codigo);
 scanf("%d", &quantidade);
 switch(codigo){
    case 1: valor = (quantidade * 4.00);
      break;
    case 2: valor = (quantidade * 4.50);
      break;
    case 3: valor = (quantidade * 5.00);
      break;
    case 4: valor = (quantidade * 2.00);
      break;
    case 5: valor = (quantidade * 1.50);
      break;
      default: printf("Codigo invalido\n");
      return 0;
 }  
    printf("Total: R$ %.2f\n", valor);

}