#include <stdio.h>
#include <string.h>

int main() {
    char s[55];
    scanf("%s", s);
    
    char vogais[55];
    int n = 0;
    
    for (int i = 0; s[i]; i++)
        if (s[i]=='a' || s[i]=='e' || s[i]=='i' || s[i]=='o' || s[i]=='u')
            vogais[n++] = s[i];
    
    int palindromo = 1;
    for (int i = 0; i < n/2; i++)
        if (vogais[i] != vogais[n-1-i]) { palindromo = 0; break; }
    
    printf("%s\n", palindromo ? "S" : "N");
    return 0;
}p