#include <stdio.h>

int main() {
    int p;
    for(int p = 1; p <= 100; p++) {
        if(p%2==0) {
         printf("%d\n", p);
        }
    }
    return 0;
}
