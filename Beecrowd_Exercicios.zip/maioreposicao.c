#include <stdio.h>

int main() {
    int numero, maior = -1, posicao_maior = 0;
    int i;
    for (i = 1; i <= 100; i++) {
        scanf("%d", &numero);
        if (numero > maior) {
            maior = numero;       
            posicao_maior = i;    
        }
    }
    printf("%d\n%d\n", maior, posicao_maior);
    return 0;
}in