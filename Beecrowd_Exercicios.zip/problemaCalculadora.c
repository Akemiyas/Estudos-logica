#include <stdio.h>

int main() {
    int N;
    scanf("%d", &N);
    
    while (N--) {
        char s[20];
        scanf("%s", s);
        
        int a = (s[2]-'0')*10 + (s[3]-'0');
        int b = (s[5]-'0')*100 + (s[6]-'0')*10 + (s[7]-'0');
        int c = (s[11]-'0')*10 + (s[12]-'0');
        
        printf("%d\n", a + b + c);
    }
    return 0;
}