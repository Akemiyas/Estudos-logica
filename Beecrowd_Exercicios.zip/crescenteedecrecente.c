#include <stdio.h>
 
int main() {
    int X, Y;
    while(scanf("%d %d", &X, &Y) == 2 && X != Y){
        if(X<Y){
            printf("Crescente\n");
        }
        else {
            printf("Decrescente\n");
        }
    }
    return 0;
}