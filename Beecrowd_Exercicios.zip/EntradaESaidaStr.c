#include <stdio.h>
#include <string.h>

int main() {
    char a[105], b[105], c[105];
    
    while (fgets(a, 105, stdin) && fgets(b, 105, stdin) && fgets(c, 105, stdin)) {
        // Remove newlines
        a[strcspn(a, "\n")] = '\0';
        b[strcspn(b, "\n")] = '\0';
        c[strcspn(c, "\n")] = '\0';
        
        printf("%s%s%s\n", a, b, c);
        printf("%s%s%s\n", b, c, a);
        printf("%s%s%s\n", c, a, b);
        printf("%.10s%.10s%.10s\n", a, b, c);
    }
    return 0;
}