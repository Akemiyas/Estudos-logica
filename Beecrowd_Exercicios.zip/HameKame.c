#include <stdio.h>
#include <string.h>

int main() {
    int C;
    scanf("%d", &C);
    while (C--) {
        char s[205];
        scanf("%s", s);
        int i = 1; 
        int n = 0;
        while (s[i] == 'a') { n++; i++; }
        i += 2; 
        i++;
        int m = 0;
        while (s[i] == 'a') { m++; i++; }
        int total = n * m;
        printf("k");
        for (int j = 0; j < total; j++) printf("a");
        printf("\n");
    }r
    return 0;
}