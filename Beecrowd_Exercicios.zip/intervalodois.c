#include <stdio.h>
int main() {
    int N, X, i;
    int in = 0;  
    int out = 0; 
    if (scanf("%d", &N) == 1) {
        for (i = 0; i < N; i++) {
            scanf("%d", &X);
            if (X >= 10 && X <= 20) {
                in++; 
            } else {
                out++; 
            }
        }
        printf("%d in\n", in);
        printf("%d out\n", out);
    }
    return 0;
}s