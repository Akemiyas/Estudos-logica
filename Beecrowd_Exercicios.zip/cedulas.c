#include <stdio.h>
int main()
{
    int cem, resto_cem, ciquenta, resto_cin, vinte, resto_vinte;
    int dez, resto_dez, cinco, resto_cinco, dois, resto_dois, um, valor;
    scanf("%d", &valor);
    cem = valor/100;
    resto_cem = valor%100;
    ciquenta = resto_cem/50;
    resto_cin = resto_cem%50;
    vinte = resto_cin/20;
    resto_vinte = resto_cin%20;
    dez = resto_vinte/10;
    resto_dez = resto_vinte%10;
    cinco = resto_dez/5;
    resto_cinco = resto_dez%5;
    dois = resto_cinco/2;
    resto_dois = resto_cinco%2;
    um = resto_dois;
    printf("%d\n", valor);
    printf("%d nota(s) de R$ 100,00\n", cem);
    printf("%d nota(s) de R$ 50,00\n", ciquenta);
    printf("%d nota(s) de R$ 20,00\n", vinte);
    printf("%d nota(s) de R$ 10,00\n", dez);
    printf("%d nota(s) de R$ 5,00\n", cinco);
    printf("%d nota(s) de R$ 2,00\n", dois);
    printf("%d nota(s) de R$ 1,00\n", um);
    return 0;
}
