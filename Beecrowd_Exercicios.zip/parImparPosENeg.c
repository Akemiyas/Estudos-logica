#include <stdio.h>

int main() {
    int n, pares=0, impares=0, positivos=0, negativos=0;

    for(int i = 0; i < 5; i++) {
        scanf("%d", &n);

        // Teste de Paridade
        if(n % 2 == 0) pares++;
        else impares++;

        // Teste de Sinal (Atenção ao zero!)
        if(n > 0) positivos++;
        else if(n < 0) negativos++; 
        // Se for zero, o "else if" ignora e não conta nada!
    }

    printf("%d valor(es) par(es)\n", pares);
    printf("%d valor(es) impar(es)\n", impares);
    printf("%d valor(es) positivo(s)\n", positivos);
    printf("%d valor(es) negativo(s)\n", negativos);

    return 0;
}