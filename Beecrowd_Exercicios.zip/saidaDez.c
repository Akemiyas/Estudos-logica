#include <stdio.h>

int main() {
    char A='A', B='B', C='C', D='D', E='E';
    printf("       %c\n", A, A);
    printf("      %c %c\n", B, B);
    printf("     %c   %c\n", C, C);
    printf("    %c     %c\n", D, D);
    printf("   %c       %c\n", E, E);
    printf("    %c     %c\n", D, D);
    printf("     %c   %c\n", C, C);
    printf("      %c %c\n", B, B);
    printf("       %c\n", A, A);
    return 0;
}
s