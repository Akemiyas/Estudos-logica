#include <stdio.h>

int main() {
    int cod1, q1, cod2, q2;
    double v1, v2, total;
    scanf("%d %d %lf", &cod1, &q1, &v1);
    scanf("%d %d %lf", &cod2, &q2, &v2);
    total = (q1 * v1) + (q2 * v2);
    printf("VALOR A PAGAR: R$ %.2f\n", total);
    return 0;
}