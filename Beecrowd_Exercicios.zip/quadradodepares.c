#include <stdio.h>
#include <math.h>

int main() {
    int n, i;
    double conta;
    if (scanf("%d", &n) == 1) {
        for (i = 1; i <= n; i++) {
            if (i % 2 == 0) {
                conta = pow(i, 2);
                printf("%d^2 = %.0f\n", i, conta);
            }
        }
    }
    return 0;
}