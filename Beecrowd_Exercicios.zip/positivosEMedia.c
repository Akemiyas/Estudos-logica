#include <stdio.h>

int main() {
    float n, media, soma=0;
    int positivos=0;
    for(int i=0;i < 6; i++){
        scanf("%f", &n);
        if(n>0){
            positivos++;
            soma = soma+n;
        }
    }
    if(positivos>0){
        media = soma/positivos;
    }
    printf("%d valores positivos\n", positivos);
    printf("%.1f\n", media);
    return 0;
}