#include <stdio.h>
int main() {
    int numero, hora;  
    double valor_hora, salario; 
    scanf("%d", &numero); 
    scanf("%d", &hora); 
    scanf("%lf", &valor_hora); 
    salario = hora * valor_hora; 
    printf("NUMBER = %d\n", numero); 
    printf("SALARY = U$ %.2f\n", salario); 
     return 0;
}